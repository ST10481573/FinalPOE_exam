package com.mycompany.quickchat;

import javax.swing.*;
import java.util.*;
import java.io.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.FileWriter;

public class Message {
    private final String messageID;
    private final int messageNum;
    private String recipient;
    String message; // package-private for test access
    String messageHash;

    public Message(int num) {
        this.messageID = generateMessageID();
        this.messageNum = num;
    }

    public void captureMessageDetails(Scanner scanner) {
        // Recipient validation
        while (true) {
            String input = JOptionPane.showInputDialog(null, "Enter recipient cell number (with international code, max 13 chars):");
            if (input == null) continue; // if user presses Cancel, ask again
            if (checkRecipientCell(input) == 1) {
                this.recipient = input;
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
            }
        }
        // Message validation
        while (true) {
            String input = JOptionPane.showInputDialog(null, "Enter your message (max 250 chars):");
            if (input == null) continue; // if user presses Cancel, ask again
            int check = checkMessageLength(input);
            if (check == 0) {
                this.message = input;
                JOptionPane.showMessageDialog(null, "Message ready to send.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + check + ", please reduce size.");
            }
        }
        this.messageHash = createMessageHash();
    }

    public String printMessage() {
        return String.format(
            "MessageID: %s\nMessage Hash: %s\nRecipient: %s\nMessage: %s",
            messageID, messageHash, recipient, message
        );
    }

    public int returnTotalMessages() {
        return messageNum;
    }

    private String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    public int checkRecipientCell(String input) {
        if (input != null && input.length() > 1 && input.length() <= 13
        && input.startsWith("+") && input.substring(1).matches("\\d+")) {
        return 1;
        }
        return 0;
    }

    public int checkMessageLength(String input) {
        if (input.length() > 250) {
            return input.length() - 250;
        }
        return 0;
    }

    public String createMessageHash() {
        String firstTwoID = messageID.substring(0,2);
        String firstWord = "", lastWord = "";
        if (message != null && !message.isEmpty()) {
            String[] words = message.trim().split("\\s+");
            firstWord = words[0];
            lastWord = words[words.length-1];
        }
        return (firstTwoID + ":" + messageNum + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sentMessage(Scanner scanner) {
        String choice = "";
        while (true) {
            String input = JOptionPane.showInputDialog(null, "Choose action: SEND / STORE / DISREGARD");
            if (input == null) continue; // if user presses Cancel, ask again
            choice = input.toUpperCase();
            if (choice.equals("SEND") || choice.equals("STORE") || choice.equals("DISREGARD")) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid option. Please select SEND, STORE, or DISREGARD.");
        }
        switch (choice) {
            case "SEND":
                JOptionPane.showMessageDialog(null, "Message successfully sent.");
                break;
            case "STORE":
                JOptionPane.showMessageDialog(null, "Message successfully stored.");
                break;
            case "DISREGARD":
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                break;
        }
        return choice;
    }

    public void storeMessage() {
        JSONObject obj = new JSONObject();
        obj.put("messageID", messageID);
        obj.put("messageNum", messageNum);
        obj.put("recipient", recipient);
        obj.put("message", message);
        obj.put("messageHash", messageHash);

        JSONArray messagesArr = new JSONArray();

        // Load previous messages
        try {
            File file = new File("stored_messages.json");
            if (file.exists()) {
                FileReader reader = new FileReader(file);
                int c;
                StringBuilder sb = new StringBuilder();
                while ((c = reader.read()) != -1) {
                    sb.append((char) c);
                }
                reader.close();
                if (!sb.toString().isEmpty()) {
                    messagesArr = (JSONArray) org.json.simple.JSONValue.parse(sb.toString());
                }
            }
        } catch (Exception e) {}

        messagesArr.add(obj);

        // Write
        try (FileWriter file = new FileWriter("stored_messages.json")) {
            file.write(messagesArr.toJSONString());
            file.flush();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }

    // For testing
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
}