/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author RC_Student_lab
 */
package com.mycompany.quickchat;

import javax.swing.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;

public class QuickChat {
    private static final Scanner scanner = new Scanner(System.in);
    private static List<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        // Login
        String user = JOptionPane.showInputDialog(null, "Enter username:");
        String pass = JOptionPane.showInputDialog(null, "Enter password:");
        if (!login(user, pass)) {
            JOptionPane.showMessageDialog(null, "Invalid login.");
            return;
        }

        int messageLimit = 0;
        while (true) {
            String input = JOptionPane.showInputDialog(null, "How many messages do you want to send?");
            try {
                messageLimit = Integer.parseInt(input);
                if (messageLimit > 0) break;
                else JOptionPane.showMessageDialog(null, "Please enter a number greater than 0.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Invalid input, try again.");
            }
        }

        int option;
        do {
            String menu = "\nChoose an option:\n" +
                          "1) Send Message\n" +
                          "2) Show Recently Sent Messages\n" +
                          "3) Quit";
            String optInput = JOptionPane.showInputDialog(null, menu + "\n\nEnter option (1, 2, or 3):");
            if (optInput == null) { // User pressed Cancel
                option = 3;
            } else {
                try {
                    option = Integer.parseInt(optInput);
                } catch (Exception e) {
                    option = -1;
                }
            }

            switch (option) {
                case 1:
                    if (totalMessagesSent >= messageLimit) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        break;
                    }
                    Message msg = new Message(totalMessagesSent + 1);
                    msg.captureMessageDetails(scanner);
                    String action = msg.sentMessage(scanner);
                    handleMessageAction(msg, action);
                    break;
                case 2:
                    if (sentMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent yet.");
                    } else {
                        StringBuilder sb = new StringBuilder();
                        for (Message m : sentMessages) {
                            sb.append(m.printMessage()).append("\n\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString(), "Recently Sent Messages", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3.");
            }
        } while (option != 3);

        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }

    // Now allows any username, but password must be 'admin123'
    private static boolean login(String user, String pass) {
        return pass.equals("admin123");
    }

    private static void handleMessageAction(Message msg, String action) {
        switch (action.toUpperCase()) {
            case "SEND":
                totalMessagesSent++;
                sentMessages.add(msg);
                JOptionPane.showMessageDialog(null, msg.printMessage(), "Message Sent", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "STORE":
                msg.storeMessage();
                JOptionPane.showMessageDialog(null, "Message successfully stored.");
                break;
            case "DISREGARD":
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Unknown action.");
        }
    }
}