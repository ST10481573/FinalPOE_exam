package com.mycompany.quickchat;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    void testMessageLengthSuccess() {
        Message msg = new Message(1);
        assertEquals(0, msg.checkMessageLength("This is a short message."));
    }

    @Test
    void testMessageLengthFailure() {
        Message msg = new Message(1);
        String longMsg = "A".repeat(260);
        assertEquals(10, msg.checkMessageLength(longMsg));
    }

    @Test
    void testRecipientSuccess() {
        Message msg = new Message(1);
        assertEquals(1, msg.checkRecipientCell("+123456789"));
    }

    @Test
    void testRecipientFailure() {
        Message msg = new Message(1);
        assertEquals(0, msg.checkRecipientCell("123456789"));
        assertEquals(0, msg.checkRecipientCell("+12345678901"));
    }

    @Test
    void testMessageHash() {
        Message msg = new Message(0);
        msg.message = "Hi tonight";
        msg.messageHash = msg.createMessageHash();
        String hash = msg.getMessageHash();
        assertTrue(hash.matches("\\d{2}:0:HITONIGHT"));
    }

    @Test
    void testMessageIDCreation() {
        Message msg = new Message(1);
        assertTrue(msg.getMessageID().length() == 10);
    }

    @Test
    void testSentMessageResponses() {
        // Not easily testable without mocking Scanner input
    }
}