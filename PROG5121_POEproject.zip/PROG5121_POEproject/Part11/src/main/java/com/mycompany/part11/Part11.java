/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part11;
import javax.swing.*;

public class Part11 {
    public String Username;
    public String Password;
    public long cellphone;

    // Method to check username
    public void CheckUserName() {
        boolean hasUnderscore = Username.contains("_");

        if (hasUnderscore && Username.length() <= 5) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null,
                    "Username is not correctly formatted.\nPlease ensure that your Username contains an underscore and is no more than five characters in length.");
            Username = JOptionPane.showInputDialog("Please enter a username");
            CheckUserName(); // recursive call until valid
        }
    }

    // Method to check password
    public boolean checkpassword(String password) {
        boolean hasUppercase = false, hasDigit = false, hasSpecialChar = false;
        String SpecialChar = "~'!@#$%^&*()_+=<>?/{}[];:'\",.";

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUppercase = true;
            if (Character.isDigit(ch)) hasDigit = true;
            if (SpecialChar.contains(String.valueOf(ch))) hasSpecialChar = true;
        }

        if (password.length() >= 8 && hasUppercase && hasDigit && hasSpecialChar) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null,
                    "Password is not correctly formatted.\nPlease ensure it has at least 8 characters, a capital letter, a number, and a special character.");
            return false;
        }
    }

    // Method to check cellphone number
    public static boolean checkCellphone(long cellphone) {
        String phoneStr = String.valueOf(cellphone);
        return phoneStr.startsWith("27") && phoneStr.length() == 11;
    }

    // Metthod to register the user
    public void RegisterUser() {
        Username = JOptionPane.showInputDialog(null, "Please enter a username");
        CheckUserName();

        boolean validPassword = false;
        while (!validPassword) {
            Password = JOptionPane.showInputDialog(null, "Please enter a password");
            validPassword = checkpassword(Password);
        }

        boolean validPhone = false;
        while (!validPhone) {
            try {
                cellphone = Long.parseLong(JOptionPane.showInputDialog(null, "Please enter a cellphone number"));
                validPhone = checkCellphone(cellphone);
                if (!validPhone) {
                    JOptionPane.showMessageDialog(null,
                            "Cellphone number incorrectly formatted.\nIt must start with 27 and be 11 digits long.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter numbers only.");
            }
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    public static void main(String[] args) {
        Part11 userSignIn = new Part11();
        userSignIn.RegisterUser();
    }
}